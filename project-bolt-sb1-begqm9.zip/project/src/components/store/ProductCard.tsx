import React, { useState } from 'react';
import { Product } from '../../types';
import { ShoppingBag } from 'lucide-react';
import { useCart } from '../../store/useCart';
import { ProductModal } from './ProductModal';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [showModal, setShowModal] = useState(false);
  const { addItem } = useCart();

  return (
    <>
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-64 object-cover cursor-pointer"
          onClick={() => setShowModal(true)}
        />
        <div className="p-4">
          <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
          <p className="text-sm text-gray-600 mb-1">Ref: {product.reference}</p>
          <p className="text-gray-600 text-sm mb-2">{product.description}</p>
          <div className="flex justify-between items-center mb-2">
            <div>
              <p className="text-gray-500 text-sm">Preço no Atacado:</p>
              <p className="text-xl font-bold text-indigo-600">
                R$ {product.wholesalePrice.toFixed(2)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-gray-500 text-sm">Pedido Mínimo:</p>
              <p className="font-semibold">{product.minOrderQuantity} peças</p>
            </div>
          </div>
          <button
            onClick={() => setShowModal(true)}
            className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
          >
            <ShoppingBag size={20} />
            Adicionar ao Carrinho
          </button>
        </div>
      </div>

      {showModal && (
        <ProductModal
          product={product}
          onClose={() => setShowModal(false)}
          onAddToCart={(quantity, size, color) => {
            addItem(product, quantity, size, color);
            setShowModal(false);
          }}
        />
      )}
    </>
  );
};
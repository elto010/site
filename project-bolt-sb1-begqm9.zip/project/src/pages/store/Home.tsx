import React from 'react';
import { ProductCard } from '../../components/store/ProductCard';
import { Cart } from '../../components/store/Cart';
import { Search, Filter } from 'lucide-react';

const categories = [
  'Todos',
  'Vestidos',
  'Blusas',
  'Calças',
  'Saias',
  'Acessórios',
];

export const StorePage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-indigo-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">Moda Feminina no Atacado</h1>
          <p className="text-xl">As últimas tendências pelos melhores preços para seu negócio</p>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Buscar produtos..."
              className="w-full pl-10 pr-4 py-2 border rounded-md"
            />
            <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
          </div>
          <div className="flex gap-4">
            <select className="px-4 py-2 border rounded-md bg-white">
              <option>Ordenar por</option>
              <option>Menor Preço</option>
              <option>Maior Preço</option>
              <option>Mais Vendidos</option>
            </select>
            <button className="flex items-center gap-2 px-4 py-2 border rounded-md bg-white">
              <Filter size={20} />
              Filtros
            </button>
          </div>
        </div>

        {/* Categories */}
        <div className="flex gap-4 mb-8 overflow-x-auto pb-2">
          {categories.map((category) => (
            <button
              key={category}
              className="px-4 py-2 rounded-full bg-white border hover:bg-indigo-50 whitespace-nowrap"
            >
              {category}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <ProductCard
            product={{
              id: '1',
              name: 'Vestido Floral Midi',
              description: 'Vestido elegante com estampa floral',
              price: 159.90,
              wholesalePrice: 89.90,
              minOrderQuantity: 10,
              stock: 100,
              image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
              category: 'dresses',
              sizes: ['P', 'M', 'G'],
              colors: ['Azul', 'Rosa'],
              createdAt: new Date(),
            }}
            onAddToCart={() => {}}
          />
        </div>
      </div>

      <Cart />
    </div>
  );
};
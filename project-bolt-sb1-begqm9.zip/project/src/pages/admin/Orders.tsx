import React, { useState } from 'react';
import { DataTable } from '../../components/DataTable';
import { Download, Printer, Send } from 'lucide-react';
import { format } from 'date-fns';

const mockOrders = [
  {
    id: '1',
    customerName: 'Maria Silva',
    total: 1250.90,
    status: 'pending',
    createdAt: new Date(),
    shippingMethod: 'Retirar no Box',
    customerPhone: '81999999999'
  },
  // Add more mock orders as needed
];

export const Orders = () => {
  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  const columns = [
    {
      header: 'Pedido',
      accessorKey: 'id',
    },
    {
      header: 'Cliente',
      accessorKey: 'customerName',
    },
    {
      header: 'Total',
      accessorKey: 'total',
      cell: ({ row }) => `R$ ${row.original.total.toFixed(2)}`,
    },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: ({ row }) => (
        <span className={`px-2 py-1 rounded-full text-sm ${
          row.original.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
          row.original.status === 'processing' ? 'bg-blue-100 text-blue-800' :
          row.original.status === 'shipped' ? 'bg-green-100 text-green-800' :
          'bg-gray-100 text-gray-800'
        }`}>
          {row.original.status}
        </span>
      ),
    },
    {
      header: 'Data',
      accessorKey: 'createdAt',
      cell: ({ row }) => format(row.original.createdAt, 'dd/MM/yyyy HH:mm'),
    },
    {
      header: 'Ações',
      cell: ({ row }) => (
        <div className="flex gap-2">
          <button 
            onClick={() => handlePrint(row.original)}
            className="p-1 hover:bg-gray-100 rounded"
          >
            <Printer size={18} />
          </button>
          <button 
            onClick={() => handleExport(row.original)}
            className="p-1 hover:bg-gray-100 rounded"
          >
            <Download size={18} />
          </button>
          <button 
            onClick={() => handleWhatsApp(row.original)}
            className="p-1 hover:bg-gray-100 rounded text-green-600"
          >
            <Send size={18} />
          </button>
        </div>
      ),
    },
  ];

  const handlePrint = (order) => {
    // Implement print functionality
    console.log('Print order:', order);
  };

  const handleExport = (order) => {
    // Implement export functionality
    console.log('Export order:', order);
  };

  const handleWhatsApp = (order) => {
    const message = `Olá ${order.customerName}, seu pedido #${order.id} foi recebido!\nTotal: R$ ${order.total.toFixed(2)}\nStatus: ${order.status}`;
    const whatsappUrl = `https://wa.me/55${order.customerPhone}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Pedidos</h2>
      
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex gap-4 mb-6">
          <input
            type="date"
            value={dateRange.start}
            onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
            className="border rounded px-3 py-2"
          />
          <input
            type="date"
            value={dateRange.end}
            onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
            className="border rounded px-3 py-2"
          />
          <button className="bg-indigo-600 text-white px-4 py-2 rounded">
            Filtrar
          </button>
        </div>

        <DataTable 
          columns={columns} 
          data={mockOrders}
        />
      </div>
    </div>
  );
};
import React, { useState } from 'react';
import { X } from 'lucide-react';
import { useCart } from '../../store/useCart';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  shippingMethod: string;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  shippingMethod,
}) => {
  const { items, total, clearCart } = useCart();
  const [customerData, setCustomerData] = useState({
    name: '',
    phone: '',
    address: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Format order message for WhatsApp
    const orderDetails = items.map(item => 
      `${item.quantity}x ${item.product.name} (${item.size}/${item.color}) - R$ ${(item.product.wholesalePrice * item.quantity).toFixed(2)}`
    ).join('\n');

    const message = `*Novo Pedido*\n\n` +
      `*Cliente:* ${customerData.name}\n` +
      `*Telefone:* ${customerData.phone}\n` +
      `*Forma de Entrega:* ${shippingMethod === 'box' ? 'Retirar no Box' : 'Enviar por Excursão'}\n` +
      (shippingMethod === 'excursao' ? `*Endereço:* ${customerData.address}\n` : '') +
      '\n*Itens do Pedido:*\n' +
      orderDetails +
      `\n\n*Total:* R$ ${total().toFixed(2)}`;

    // Send to WhatsApp
    const phoneNumber = '5581996506060';
    window.open(
      `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`,
      '_blank'
    );

    // Clear cart and close modal
    clearCart();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-lg font-semibold">Finalizar Pedido</h2>
          <button onClick={onClose}>
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4">
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Nome Completo
            </label>
            <input
              type="text"
              required
              value={customerData.name}
              onChange={(e) => setCustomerData(prev => ({ ...prev, name: e.target.value }))}
              className="w-full border rounded px-3 py-2"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Telefone (WhatsApp)
            </label>
            <input
              type="tel"
              required
              value={customerData.phone}
              onChange={(e) => setCustomerData(prev => ({ ...prev, phone: e.target.value }))}
              className="w-full border rounded px-3 py-2"
              placeholder="(81) 99999-9999"
            />
          </div>

          {shippingMethod === 'excursao' && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Endereço para Entrega
              </label>
              <textarea
                required
                value={customerData.address}
                onChange={(e) => setCustomerData(prev => ({ ...prev, address: e.target.value }))}
                className="w-full border rounded px-3 py-2"
                rows={3}
              />
            </div>
          )}

          <div className="mb-6">
            <div className="flex justify-between items-center text-sm text-gray-600">
              <span>Forma de Entrega:</span>
              <span>{shippingMethod === 'box' ? 'Retirar no Box' : 'Enviar por Excursão'}</span>
            </div>
            <div className="flex justify-between items-center mt-2 text-lg font-semibold">
              <span>Total:</span>
              <span>R$ {total().toFixed(2)}</span>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-3 rounded-md hover:bg-indigo-700 transition-colors"
          >
            Confirmar Pedido
          </button>
        </form>
      </div>
    </div>
  );
};
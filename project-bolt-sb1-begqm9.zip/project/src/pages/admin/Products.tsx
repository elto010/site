import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { DataTable } from '../../components/DataTable';
import { ProductForm } from '../../components/admin/ProductForm';

const mockProducts = [
  {
    id: '1',
    name: 'Vestido Floral Midi',
    reference: 'VF-001',
    weight: 300,
    category: 'Vestidos',
    price: 159.90,
    wholesalePrice: 89.90,
    stock: 100,
  },
  // Add more mock products
];

export const Products = () => {
  const [showForm, setShowForm] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const columns = [
    {
      header: 'Referência',
      accessorKey: 'reference',
    },
    {
      header: 'Nome',
      accessorKey: 'name',
    },
    {
      header: 'Categoria',
      accessorKey: 'category',
    },
    {
      header: 'Peso (g)',
      accessorKey: 'weight',
    },
    {
      header: 'Preço Atacado',
      accessorKey: 'wholesalePrice',
      cell: ({ row }) => `R$ ${row.original.wholesalePrice.toFixed(2)}`,
    },
    {
      header: 'Estoque',
      accessorKey: 'stock',
    },
  ];

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Produtos</h2>
        <button
          onClick={() => {
            setSelectedProduct(null);
            setShowForm(true);
          }}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-indigo-700"
        >
          <Plus size={20} />
          Novo Produto
        </button>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <DataTable columns={columns} data={mockProducts} />
      </div>

      {showForm && (
        <ProductForm
          product={selectedProduct}
          onClose={() => setShowForm(false)}
          onSubmit={(data) => {
            console.log('Product data:', data);
            setShowForm(false);
          }}
        />
      )}
    </div>
  );
};
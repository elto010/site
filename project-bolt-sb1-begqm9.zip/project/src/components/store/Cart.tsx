import React from 'react';
import { X, ShoppingBag } from 'lucide-react';
import { useCart } from '../../store/useCart';
import { CheckoutModal } from './CheckoutModal';

export const Cart = () => {
  const { items, removeItem, updateQuantity, total } = useCart();
  const [isOpen, setIsOpen] = React.useState(false);
  const [shippingMethod, setShippingMethod] = React.useState('box');
  const [showCheckout, setShowCheckout] = React.useState(false);

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed top-4 right-4 bg-indigo-600 text-white p-3 rounded-lg shadow-lg hover:bg-indigo-700 transition-colors flex items-center gap-2"
      >
        <ShoppingBag size={20} />
        <span className="font-semibold">Carrinho</span>
        {totalItems > 0 && (
          <span className="bg-red-500 text-white rounded-full px-2 py-1 text-xs">
            {totalItems}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50">
          <div className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-lg">
            <div className="p-4 flex justify-between items-center border-b">
              <h2 className="text-lg font-semibold">Carrinho ({totalItems} itens)</h2>
              <button onClick={() => setIsOpen(false)}>
                <X size={24} />
              </button>
            </div>

            <div className="p-4 flex-1 overflow-y-auto">
              {items.map((item) => (
                <div key={`${item.product.id}-${item.size}-${item.color}`} className="flex gap-4 mb-4 pb-4 border-b">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-20 h-20 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold">{item.product.name}</h3>
                    <p className="text-sm text-gray-600">
                      Ref: {item.product.reference}
                    </p>
                    <p className="text-sm text-gray-600">
                      Tamanho: {item.size} | Cor: {item.color}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <input
                        type="number"
                        min={item.product.minOrderQuantity}
                        value={item.quantity}
                        onChange={(e) => updateQuantity(item.product.id, parseInt(e.target.value))}
                        className="w-20 border rounded px-2 py-1"
                      />
                      <button
                        onClick={() => removeItem(item.product.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <X size={20} />
                      </button>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">
                      R$ {(item.product.wholesalePrice * item.quantity).toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t p-4">
              <div className="mb-4">
                <h3 className="font-semibold mb-2">Forma de Entrega:</h3>
                <select
                  value={shippingMethod}
                  onChange={(e) => setShippingMethod(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                >
                  <option value="box">Retirar no Box</option>
                  <option value="excursao">Enviar por Excursão</option>
                </select>
              </div>

              <div className="flex justify-between items-center mb-4">
                <span className="font-semibold">Total:</span>
                <span className="text-xl font-bold">R$ {total().toFixed(2)}</span>
              </div>

              <button
                onClick={() => {
                  setShowCheckout(true);
                  setIsOpen(false);
                }}
                disabled={items.length === 0}
                className="w-full bg-indigo-600 text-white py-3 rounded-md hover:bg-indigo-700 transition-colors disabled:bg-gray-400"
              >
                Finalizar Pedido
              </button>
            </div>
          </div>
        </div>
      )}

      <CheckoutModal
        isOpen={showCheckout}
        onClose={() => setShowCheckout(false)}
        shippingMethod={shippingMethod}
      />
    </>
  );
};
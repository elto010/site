export interface Product {
  id: string;
  name: string;
  description: string;
  reference: string;
  weight: number;
  price: number;
  wholesalePrice: number;
  minOrderQuantity: number;
  stock: number;
  image: string;
  category: 'dresses' | 'tops' | 'bottoms' | 'accessories' | 'outerwear';
  sizes: string[];
  colors: string[];
  createdAt: Date;
}

export interface CartItem {
  product: Product;
  quantity: number;
  size: string;
  color: string;
}

// Rest of the existing types remain the same